%-----     Fuction: Errors of G_K and Vexa for Example 3.1    -----%


function [ErroG ErroV]=Error(M_V,M_GK) 
global Vexa G_K N J L T

%-----           Calculing the Error  for G_K          ------%
 for i=1:J 
   if(G_K(i)==0 )
     ErrorG(i)= abs( M_GK(i) );end 
   if(G_K(i)~=0 )
   ErrorG(i)=abs( ( G_K(i) -M_GK(i) )./G_K(i) );
   end
 end	 
 ErroG =L/J*sum ( ErrorG) *100;   

%-----           Calculing the Error  for Vexa          -----%
for i=1:N 
   if(Vexa(i,1)==0 && Vexa(i,J)~=0)
     ErrorV(i)= abs( M_V(i,1) )+abs( ( Vexa(i,J) -M_V(i,J) )./Vexa(i,J) );end
   if(Vexa(i,1)~=0 && Vexa(i,J)==0)
     ErrorV(i)= abs( ( Vexa(i,1) -M_V(i,1) )./Vexa(i,1) )+abs( M_V(i,J) );end
   if(Vexa(i,1)==0 && Vexa(i,J)==0)
     ErrorV(i)= abs( M_V(i,1) )+abs( M_V(i,J) );                          end  
   if(Vexa(i,1)~=0 && Vexa(i,J)~=0)
     ErrorV(i)=abs( ( Vexa(i,1) -M_V(i,1) )./Vexa(i,1) )+ ...
               abs( ( Vexa(i,J) -M_V(i,J) )./Vexa(i,J) ) ;                end
 end
 ErroV =1/2*T/N*sum (ErrorV) *100; 

%%-----           Calculing the Error  for Vexa          ------2
%for i=1:N 
%     ErrorV(i)=( Vexa(i,1) -M_V(i,1) )^2 +( Vexa(i,J) -M_V(i,J) )^2;
%end
% ErroV =1/2*T/N*sqrt( sum(ErrorV) )*100; 

