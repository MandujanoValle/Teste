%-----  Fuction: Mean and Standard deviation for Example 3.1  -----% 


function [M_V M_GK SD_V SD_GK]=mean_std(delta) 
global  N_E 

%%-----   To calculate the Mean and Standard Deviation       -----%%
 M_V   = 0*importdata(sprintf('Data%d/Vp%d.txt',delta,1));
 M_GK  = 0*importdata(sprintf('Data%d/GK%d.txt',delta,1));

 SD_V  = 0*importdata(sprintf('Data%d/Vp%d.txt',delta,1));
 SD_GK = 0*importdata(sprintf('Data%d/GK%d.txt',delta,1));


 for i=1:N_E
  M_V  = M_V  + importdata(sprintf('Data%d/Vp%d.txt',delta,i)) ;
  M_GK = M_GK + importdata(sprintf('Data%d/GK%d.txt',delta,i)); 
 end
 M_V= M_V/N_E;  M_GK = M_GK/N_E;

 for i=1:N_E
  SD_GK = SD_GK + ( M_GK-importdata(sprintf('Data%d/GK%d.txt',delta,i)) ).^2;
  SD_V  = SD_V  + ( M_V -importdata(sprintf('Data%d/Vp%d.txt',delta,i)) ).^2;
 end

 SD_GK = sqrt(SD_GK/N_E);   SD_V = sqrt(SD_V/N_E);
