%-----     Fuction: Errors of G_K and Vexa for Example 3.3    -----%
function [ErroG ErroV]=Error(M_V,M_GK,M_GNa)
global Vexa G_K G_Na T N L J 

%-----           Calculing the Error  for G_K+G_NA         ------%

  for i=1:J
   if(G_K(i)==0)
    ErrorG_K(i)=abs( M_GK(i) );                        end
   if(G_K(i)~=0)                                    
    ErrorG_K(i)=abs( (G_K(i) -M_GK(i) )./G_K(i) );     end
   if(G_Na(i)==0)                                   
    ErrorG_Na(i)=abs( M_GNa(i) );                      end
   if(G_Na(i)~=0)                          
    ErrorG_Na(i)=abs( (G_Na(i) -M_GNa(i) )./G_Na(i) ); end
  end

  ErroG =1/2*L/J*(  sum ( ErrorG_K + ErrorG_Na ) )*100;
 

%-----           Calculing the Error  for Vexa          ------%
for i=1:N
  for j=1:J 
   if(Vexa(i,j)==0) 
     ErrorV(i,j)= abs( M_V(i,j) ); end

   if(Vexa(i,j)~=0)
     ErrorV(i,j)=abs( ( Vexa(i,j) -M_V(i,j) )./Vexa(i,j) );end
  end
end
 ErroV =T/N*L/J*sum( sum( (ErrorV) ) ) *100; 

%-----           Calculing the Error  for Vexa          ------%
%for i=1:(N+1)/2
%  for j=1:J 
%      ErrorV(i,j)= ( Vexa(i,j) -M_V(i,j) )^2 ;
%  end
%end
% ErroV =T/(N+1)*L/J*sqrt( sum( sum( (ErrorV) ) ) )*100; 
