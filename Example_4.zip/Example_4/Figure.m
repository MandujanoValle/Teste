%%-----------------------------------------------------------------%%
%%                             Figures                             %%
%%                           Example 3.2                           %%
%%-----------------------------------------------------------------%%
clc;close all;clear all
%%-----       To import Vexa, MVp, GK, GK1, t, x              -----%%
%--   j=1 => 25%,     j=2 => 5%,    j=3 => 1%,    j=4 => 0.2      --% 
for j=1:4;
i=5^(3-j);     if (i<1) i=0; end

%%-----       To import Vexa, MVp, GK, GK1, t, x               -----%%
 M_V    = importdata(sprintf('Data%d/M_V.txt'  ,j)); 
% M_Ve1  = M_V(:,1:11);   M_Ve2 = M_V(:,11:21);  M_Ve3 = M_V(:,22:42);
  M_Ve1  = M_V([1 5:5:2000],1:11);   M_Ve2 = M_V([1 5:5:2000],11:21);  M_Ve3 = M_V([1 5:5:2000],22:42);

 M_GK   = importdata(sprintf('Data%d/M_GK.txt' ,j));
 M_GKe1 = M_GK(1:11);   M_GKe2 = M_GK(11:21);   M_GKe3 = M_GK(22:42); 

 SD_V   = importdata(sprintf('Data%d/SD_V.txt' ,j));
% SD_Ve1 = SD_V(:,1:11);   SD_Ve2 = SD_V(:,11:21);  SD_Ve3 = SD_V(:,22:42); 
 SD_Ve1 = SD_V([1 5:5:2000],1:11);   SD_Ve2 = SD_V([1 5:5:2000],11:21);  SD_Ve3 = SD_V([1 5:5:2000],22:42); 

 SD_GK  = importdata(sprintf('Data%d/SD_GK.txt',j));
 SD_GKe1= SD_GK(1:11);   SD_GKe2 = SD_GK(11:21);  SD_GKe3 = SD_GK(22:42);
 
 Vexa   = importdata(sprintf('Data%d/Vexa.txt' ,j));
% Vexae1 = Vexa(:,1:11);   Vexae2 = Vexa(:,11:21);  Vexae3 = Vexa(:,22:42); 
 Vexae1 = Vexa([1 5:5:2000],1:11);   Vexae2 = Vexa([1 5:5:2000],11:21);  Vexae3 = Vexa([1 5:5:2000],22:42); 

 GK     = importdata(sprintf('Data%d/GK.txt'   ,j));
 GKe1   = GK(1:11);   GKe2 = GK(11:21);  GKe3 = GK(22:42); 

 t     = importdata(sprintf('Data%d/t.txt'    ,j)); t=t( [1 5:5:2000] );

 x     = importdata(sprintf('Data%d/x.txt'    ,j));
 xe1 = x(1:11);   xe2 = x(11:21);  xe3 = x(22:42); 

%%%%%%-----------------    Edge e_1    -----------------%%%%%%
 [X1,T]= meshgrid(xe1,t);

%--------------- Figures of  Vexa and M_V   -----------------%
figure;
subplot(221);
set(gcf,'position',[500 528 1028 1000]); 
set(gca,'fontsize',10);
surf(X1,T,Vexae1);
colormap;
xlabel('Space [cm]','fontsize',10);
ylabel('Time [ms]','fontsize',10);
zlabel('V [mV]','fontsize',10);
title('Subplot A: Edge e_1','fontsize',10);
shading flat
 
subplot(222);
set(gcf,'position',[500 528 1028 1000]); 
set(gca,'fontsize',10)
surf(X1,T,M_Ve1);
colormap;
xlabel('Space [cm]','fontsize',10);
ylabel('Time [ms]','fontsize',10);
zlabel('\mu_{V^\delta} [mV]','fontsize',10);
title('Subplot B: Edge e_1 ','fontsize',10);
shading flat

saveas(gcf,sprintf('Figures/%d_Percent/e1Fig1.eps',i), 'psc2')

%------------- Figures of SD_V and Vexa-V_M  -------------%
figure;
subplot(221);
set(gcf,'position',[500 528 1028 1000]); 
set(gca,'fontsize',10);
surf(X1,T,SD_Ve1 );
colormap;
xlabel('Space [cm]','fontsize',10);
ylabel('Time [ms]','fontsize',10); 
zlabel('\sigma_{V^\delta} [mV]','fontsize',10); 
title('Subplot C: Edge e_1','fontsize',10);
shading flat

subplot(222);
set(gcf,'position',[500 528 1028 1000]); 
set(gca,'fontsize',10);
surf(X1,T,Vexae1-M_Ve1 );
colormap;
xlabel('Space [cm]','fontsize',10);
ylabel('Time [ms]','fontsize',10);  
zlabel('V-\mu_{V^\delta} [mV]','fontsize',10);
title('Subplot D: Edge e_1','fontsize',10);
shading flat
 
saveas(gcf,sprintf('Figures/%d_Percent/e1Fig2.eps',i), 'psc2')
 
%---------    Figures of GK and M_GK      ------------%
figure;
subplot(221);
set(gcf,'position',[500 528 1028 1000]); 
set(gca,'fontsize',10)
plot(xe1,GKe1,'b','LineWidth',1,'MarkerSize',8);
xlabel('Space [cm]','fontsize',10);
ylabel('G_K [mS/cm^2]','fontsize',10);
ylim( [ min([GKe1,M_GKe1]) max([GKe1,M_GKe1]) ] );
title('Subplot A: Edge e_1','fontsize',10)  
 
subplot(222);
set(gcf,'position',[500 528 1028 1000]); 
set(gca,'fontsize',10)
plot(xe1,M_GKe1,'b','LineWidth',1,'MarkerSize',8);
xlabel('space [cm]','fontsize',10);
ylabel('\mu_{G_K^{k_*,\delta}} [mS/cm^2]','fontsize',10);
ylim( [ min([GKe1,M_GKe1]) max([GKe1,M_GKe1]) ] );
title('Subplot B: Edge e_1','fontsize',10)
 
saveas(gcf,sprintf('Figures/%d_Percent/e1Fig3.eps',i), 'psc2')
 
%---------    Figures SD_GK and GK-M_GK    ----------%
 figure;
 subplot(221);
 set(gcf,'position',[500 528 1028 1000]); 
 set(gca,'fontsize',10)
 plot(xe1,SD_GKe1,'b','LineWidth',1,'MarkerSize',8);
 xlabel('Space [cm]','fontsize',10);
 ylabel('\sigma_{G_K^{k_*,\delta}} [mS/cm^2]','fontsize',10);
 title('Subplot C: Edge e_1','fontsize',10)  
 
 subplot(222);
 set(gcf,'position',[500 528 1028 1000]); 
 set(gca,'fontsize',10)
 plot(xe1,GKe1-M_GKe1,'b','LineWidth',1,'MarkerSize',8);
 xlabel('Space [cm]','fontsize',10);
 ylabel('G_K-\mu_{{G_K^{k_*,\delta}}} [mS/cm^2]','fontsize',10);  
 title('Subplot D: Edge e_1','fontsize',10)

 saveas(gcf,sprintf('Figures/%d_Percent/e1Fig4.eps',i), 'psc2')


%%%%%%-----------------    Edge e_2    -----------------%%%%%%
[X2,T]= meshgrid(xe2,t);


%--------------- Figures of  Vexa and M_V   -----------------%

 figure;
 subplot(221);
 set(gcf,'position',[500 528 1028 1000]); 
 set(gca,'fontsize',10);
 surf(X2,T,Vexae2);
 colormap;
 xlabel('Space [cm]','fontsize',10);
 ylabel('Time [ms]','fontsize',10);
 zlabel('V [mV]','fontsize',10);
 title('Subplot A: Edge e_2','fontsize',10);
 shading flat
 
 subplot(222);
 set(gcf,'position',[500 528 1028 1000]); 
 set(gca,'fontsize',10)
 surf(X2,T,M_Ve2);
 colormap;
 xlabel('Space [cm]','fontsize',10);
 ylabel('Time [ms]','fontsize',10);
 zlabel('\mu_{V^\delta} [mV]','fontsize',10);
 title('Subplot B: Edge e_2 ','fontsize',10);
 shading flat
 saveas(gcf,sprintf('Figures/%d_Percent/e2Fig1.eps',i), 'psc2')

%------------- Figures of SD_V and Vexa-V_M  -------------%
 figure;
 subplot(221);
 set(gcf,'position',[500 528 1028 1000]); 
 set(gca,'fontsize',10);
 surf(X2,T,SD_Ve2 );
 colormap;
 xlabel('Space [cm]','fontsize',10);
 ylabel('Time [ms]','fontsize',10); 
 zlabel('\sigma_{V^\delta} [mV]','fontsize',10); 
 title('Subplot C: Edge e_2','fontsize',10);
 shading flat

 subplot(222);
 set(gcf,'position',[500 528 1028 1000]); 
 set(gca,'fontsize',10);
 surf(X2,T,Vexae2-M_Ve2 );
 colormap;
 xlabel('Space [cm]','fontsize',10);
 ylabel('Time [ms]','fontsize',10);  
 zlabel('V-\mu_{V^\delta} [mV]','fontsize',10);
 title('Subplot D: Edge e_2','fontsize',10);
 shading flat
 
 saveas(gcf,sprintf('Figures/%d_Percent/e2Fig2.eps',i), 'psc2')
 
 
%---------    Figures of GK and M_GK      ------------%
 figure;
 subplot(221);
 set(gcf,'position',[500 528 1028 1000]); 
 set(gca,'fontsize',10)
 plot(xe2,GKe2,'b','LineWidth',1,'MarkerSize',8);
 xlabel('Space [cm]','fontsize',10);
 ylabel('G_K [mS/cm^2]','fontsize',10);
 ylim( [ min([GKe2,M_GKe2]) max([GKe2,M_GKe2]) ] );
 title('Subplot A: Edge e_2','fontsize',10)  
 
 subplot(222);
 set(gcf,'position',[500 528 1028 1000]); 
 set(gca,'fontsize',10)
 plot(xe2,M_GKe2,'b','LineWidth',1,'MarkerSize',8);
 xlabel('space [cm]','fontsize',10);
 ylabel('\mu_{G_K^{k_*,\delta}} [mS/cm^2]','fontsize',10);
 ylim( [ min([GKe2,M_GKe2]) max([GKe2,M_GKe2]) ] );
 title('Subplot B: Edge e_2','fontsize',10)
 
 saveas(gcf,sprintf('Figures/%d_Percent/e2Fig3.eps',i), 'psc2')
 
%---------    Figures SD_GK and GK-M_GK    ----------%
 figure;
 subplot(221);
 set(gcf,'position',[500 528 1028 1000]); 
 set(gca,'fontsize',10)
 plot(xe2,SD_GKe2,'b','LineWidth',1,'MarkerSize',8);
 xlabel('Space [cm]','fontsize',10);
 ylabel('\sigma_{G_K^{k_*,\delta}} [mS/cm^2]','fontsize',10);
 title('Subplot C: Edge e_2','fontsize',10)  
 
 subplot(222);
 set(gcf,'position',[500 528 1028 1000]); 
 set(gca,'fontsize',10)
 plot(xe2,GKe2-M_GKe2,'b','LineWidth',1,'MarkerSize',8);
 xlabel('Space [cm]','fontsize',10);
 ylabel('G_K-\mu_{{G_K^{k_*,\delta}}} [mS/cm^2]','fontsize',10);  
 title('Subplot D: Edge e_2','fontsize',10)

 saveas(gcf,sprintf('Figures/%d_Percent/e2Fig4.eps',i), 'psc2')



%%%%%%-----------------    Edge e_3    -----------------%%%%%%
[X3,T]= meshgrid(xe3,t);


%--------------- Figures of  Vexa and M_V   -----------------%

 figure;
 subplot(221);
 set(gcf,'position',[500 528 1028 1000]); 
 set(gca,'fontsize',10);
 surf(X3,T,Vexae3);
 colormap;
 xlabel('Space [cm]','fontsize',10);
 ylabel('Time [ms]','fontsize',10);
 zlabel('V [mV]','fontsize',10);
 xlim( [ 0.1 0.301 ] );
 title('Subplot A: Edge e_3','fontsize',10);
 shading flat
 
 subplot(222);
 set(gcf,'position',[500 528 1028 1000]); 
 set(gca,'fontsize',10)
 surf(X3,T,M_Ve3);
 colormap;
 xlabel('Space [cm]','fontsize',10);
 ylabel('Time [ms]','fontsize',10);
 zlabel('\mu_{V^\delta} [mV]','fontsize',10);
 xlim( [ 0.1 0.301 ] );
 title('Subplot B: Edge e_3 ','fontsize',10);
 shading flat
 saveas(gcf,sprintf('Figures/%d_Percent/e3Fig1.eps',i), 'psc2')

%------------- Figures of SD_V and Vexa-V_M  -------------%
 figure;
 subplot(221);
 set(gcf,'position',[500 528 1028 1000]); 
 set(gca,'fontsize',10);
 surf(X3,T,SD_Ve3 );
 colormap;
 xlabel('Space [cm]','fontsize',10);
 ylabel('Time [ms]','fontsize',10); 
 zlabel('\sigma_{V^\delta} [mV]','fontsize',10); 
 xlim( [ 0.1 0.301 ] );
 title('Subplot C: Edge e_3','fontsize',10);
 shading flat

 subplot(222);
 set(gcf,'position',[500 528 1028 1000]); 
 set(gca,'fontsize',10);
 surf(X3,T,Vexae3-M_Ve3 );
 colormap;
 xlabel('Space [cm]','fontsize',10);
 ylabel('Time [ms]','fontsize',10);  
 zlabel('V-\mu_{V^\delta} [mV]','fontsize',10);
 xlim( [ 0.1 0.301 ] );
 title('Subplot D: Edge e_3','fontsize',10);
 shading flat
 
 saveas(gcf,sprintf('Figures/%d_Percent/e3Fig2.eps',i), 'psc2')
 
 
%---------    Figures of GK and M_GK      ------------%
 figure;
 subplot(221);
 set(gcf,'position',[500 528 1028 1000]); 
 set(gca,'fontsize',10)
 plot(xe3,GKe3,'b','LineWidth',1,'MarkerSize',8);
 xlabel('Space [cm]','fontsize',10);
 ylabel('G_K [mS/cm^2]','fontsize',10);
 xlim( [ 0.1 0.301 ] );
 ylim( [ min([GKe3,M_GKe3]) max([GKe3,M_GKe3]) ] );
 title('Subplot A: Edge e_3','fontsize',10)  
 
 subplot(222);
 set(gcf,'position',[500 528 1028 1000]); 
 set(gca,'fontsize',10)
 plot(xe3,M_GKe3,'b','LineWidth',1,'MarkerSize',8);
 xlabel('space [cm]','fontsize',10);
 ylabel('\mu_{G_K^{k_*,\delta}} [mS/cm^2]','fontsize',10);
 xlim( [ 0.1 0.301 ] );
 ylim( [ min([GKe3,M_GKe3]) max([GKe3,M_GKe3]) ] );
 title('Subplot B: Edge e_3','fontsize',10)
 
 saveas(gcf,sprintf('Figures/%d_Percent/e3Fig3.eps',i), 'psc2')
 
%---------    Figures SD_GK and GK-M_GK    ----------%
 figure;
 subplot(221);
 set(gcf,'position',[500 528 1028 1000]); 
 set(gca,'fontsize',10)
 plot(xe3,SD_GKe3,'b','LineWidth',1,'MarkerSize',8);
 xlabel('Space [cm]','fontsize',10);
 ylabel('\sigma_{G_K^{k_*,\delta}} [mS/cm^2]','fontsize',10);
 xlim( [ 0.1 0.301 ] );
 title('Subplot C: Edge e_3','fontsize',10)  
 
 subplot(222);
 set(gcf,'position',[500 528 1028 1000]); 
 set(gca,'fontsize',10)
 plot(xe3,GKe3-M_GKe3,'b','LineWidth',1,'MarkerSize',8);
 xlabel('Space [cm]','fontsize',10);
 ylabel('G_K-\mu_{{G_K^{k_*,\delta}}} [mS/cm^2]','fontsize',10);  
 xlim( [ 0.1 0.301 ] );
 title('Subplot D: Edge e_3','fontsize',10)

 saveas(gcf,sprintf('Figures/%d_Percent/e3Fig4.eps',i), 'psc2')

end
