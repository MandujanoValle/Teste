%%-------------------------------------%%
%%     Solution of V and U             %%
%%          Example 3.4                %%
%%      Explicit Euluer Method         %%
%%-------------------------------------%%
function [V U]=Vkaprox(Vp,b,c)  
global  d  J1 J2 a dx dt C_M N p

%----------------- Calculating the matrix A ------------------% 
A=zeros(J2,J2);
for i=1:J2-1
A(i,i+1)=a;    A(i+1,i+1)=b(i+1);    A(i+1,i)=a;  
end
A(1,1)=b(1)+a; A(J1,J1)=b(J1)+a; A(J1+1,J1+1)=b(J1+1)+a; A(J2,J2)=b(J2)+a; 
A(J1,J1+1)=0;    A(J1+1,J1)=0;

%--------------               find V              -------------%
V=zeros(N,J2);
for n=1:N-1                                                      
c(1)=c(1)-a*dx*p(n);
V(n+1,:)=( A*V(n,:)' + c' )';
end                                                               

%--------------                find U              -------------%
U=zeros(N,J2);
D=dt/C_M*(Vp-V)';
for n=1:N-1
U(N-n,:)=( A*U(N-n+1,:)'+D(:,N-n+1) )';
end

