%%%%%%%%       To understand the code read article     %%%%%%%%%%%
%%       A COMPUTATIONAL APPROACH FOR THE INVERSE PROBLEM OF     % 
%%               NEURAL CONDUCTANCES DETERMINATION               %
%%                        Example 3.4                            %
%%                                                               %              
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                                                  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%   Figure  %%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                %
%            J     J1+1                 J2                       %
%            ↑       ↑       ...           ↑                     %
%            ------------------------------|                     %
%            |                             L2                    %
%   |------- L                                                   %
%   0        |                                                   %
%   |        -------------------------------------|              %
%   ↓            ↓                                L1             %
%   ↓            ↓                                ↓              %
%   1  2 3...J  J+1     ...                       J1             %
%                                                                %
%  % x1: Vector from x0 to xb                                    %
%  % x2: Vector from xb to xL1                                   %
%  % x3: Vector from xb to xL2                                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                                                                   
clc;close all;clear all                                            
global d J1 J2 a dx dt C_M N p Na Nb Vexa tau E_K a  C_M G_L E_L T G_K N_E L               
%%%%%%%%%%%         Start: defining PDE      %%%%%%%%%%%%%%%%%%%%| 
                                                                %|
%---          Set the temporal variabel  [0 T]               ---%|
T=20;  N=2000;  t=linspace(0,T,N);  dt=t(2)-t(1);               %|
L=0.4;                                                          %|
                                                                %|
%---               Set the parameters                        ---%|
ra=0.0238; R=35.4; C_M=1; E_K=-12; E_Na=115; E_L=10.6; G_L=0.3; %|
                                                                %|
%---                  Noise of V                             ---%|
Na=1/2; Nb=1/2;    % Na: Multiplicate noise, Nb: Additive noise %|
                                                                %|
%%%-----------------       Bifurcation       -----------------%%%|
                                                                %|
%dx=0.05;                                                       %|
%x1=0:dx:0.75;         % vector x1 from 0 to J                  %|
%x2=0.75+dx:dx:1.50;      % vector x2 from J to J1              %|
%x3=0.75:dx:2.25;      % vector x3 from J to J2                 %|
                                                                %|
dx=0.01;                                                        %|
x1=0:dx:0.1;           % vector x1 from 0 to J                  %|
x2=0.1+dx:dx:0.2;      % vector x2 from J to J1                 %|
x3=0.1:dx:0.3;         % vector x3 from J to J2                 %|
                                                                %|
x=[x1 x2 x3];                                                   %|
                                                                %|
J =length(x1);         % Number of poiNs from 0 to J            %|
J1=length([x1 x2] );   % Number of poiNs from 0 to J1           %|
J2=length(x);          % Number of poiNs from J to J2           %|
                                                                %|
%%%-----------------------------------------------------------%%%|
                                                                %|
%---                Boundary condition                       ---%|
p=-0.1*R/(pi*ra.^2)*t.^2.*exp(-10*t);                           %|
                                                                %|
%---                  Guess initial                             %|
G_Kk=0*x;                                                       %|
                                                                %|
%---                 Goal function (g_K)                     ---%|
G_K =0.2+0.2./( 1+exp( ( 0.1/2-x )/0.01 ) );                    %|
                                                                %|
%---     Perturbation of the Voltage (in perceNage )         ---%|
DEL=1.0/100;                                                    %|
                                                                %|
%---                For the stop criterion                   ---%|
tau =1.01;                                                      %|
                                                                %|
%---           Number of experiments                         ---%|
N_E=50;                                                         %|
                                                                %|
%%%%%%%%%-------             End              -------%%%%%%%%%%%%|
                                                    
%-------           We denote the constaNs              ---------%
a = dt*ra/(C_M*2*R*dx^2); 
                                       
%-------         Calculating Vexa given  G_K           ---------%
b = 1 - 2*a - dt/C_M*G_L - dt/C_M*G_K ;
c = dt/C_M*G_L*E_L + dt/C_M*G_K*E_K   ;

[Vexa Uexa]=Vkaprox(zeros(N,J2),b,c)  ;

%-------     Algorithm: Minimal Error method           ---------% 

for j=1:4

 %-------      DEL: Noise                              ---------%  
 DEL=25/(5^(j-1)*100);   
                        
 save(sprintf('Data%d/Vexa.txt',j),'Vexa', '-ascii' )
 save(sprintf('Data%d/GK.txt'  ,j),'G_K' , '-ascii' )
 save(sprintf('Data%d/t.txt'   ,j),'t'   , '-ascii' )
 save(sprintf('Data%d/x.txt'   ,j),'x'   , '-ascii' )
 %G_Kk =0*x;

 for i=1:N_E
  G_Kk=0*x;

 %-------     Function: Minimal Error method          ---------% 
  [Vp G_Kk]=MinimalError(DEL,G_Kk); 
  save(sprintf('Data%d/Vp%d.txt',j,i) ,'Vp'   , '-ascii' )
  save(sprintf('Data%d/GK%d.txt',j,i) ,'G_Kk' , '-ascii' )
 end

 %-------     Function: Mean and Standard deviation   --------% 
 [M_V M_GK SD_V SD_GK]=mean_std(j);
 save( sprintf('Data%d/M_V.txt'  ,j) ,'M_V'   , '-ascii' ) 
 save( sprintf('Data%d/M_GK.txt' ,j) ,'M_GK'  , '-ascii' )
 save( sprintf('Data%d/SD_V.txt' ,j) ,'SD_V'  , '-ascii' )
 save( sprintf('Data%d/SD_GK.txt',j) ,'SD_GK' , '-ascii' )

 %-------     Function: Error for G_K and Vexa       --------%
 [ErroG ErroV]=Error(M_V,M_GK);

 %-------     Print of errors                        --------%
 fprintf('%10.4f\t\t',5^(3-j),ErroG, ErroV);
 fprintf('\n\n'); 

end
