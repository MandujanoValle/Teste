%-----     Fuction: Errors of G_K and Vexa for Example 3.2    -----%


function [ErroG ErroV]=Error(M_V,M_GK) 
global Vexa G_K T N L J2 L

%-----           Calculing the Error  for G_K          ------%
 for i=1:J2 
   if(G_K(i)==0 )
     ErrorG(i)= abs( M_GK(i) );end 
   if(G_K(i)~=0 )
   ErrorG(i)=abs( ( G_K(i) -M_GK(i) )./G_K(i) );
   end
 end	 
 ErroG =L/J2*sum ( ErrorG) *100; 

%-----           Calculing the Error  for Vexa          ------%
for i=1:(N+1)/2
  for j=1:J2 
   if(Vexa(i,j)==0) 
     ErrorV(i,j)= abs( M_V(i,j) ); end

   if(Vexa(i,j)~=0)
     ErrorV(i,j)=abs( ( Vexa(i,j) -M_V(i,j) )./Vexa(i,j) );end
  end
end
 ErroV =T/(N+1)*L/J2*sum( sum( (ErrorV) ) ) *100; 

%-----           Calculing the Error  for Vexa          ------%
%for i=1:(N+1)/2
%  for j=1:J2 
%     ErrorV(i,j)= ( Vexa(i,j) -M_V(i,j) )^2;
%  end
%end
% ErroV =T/(N+1)*L/J2*sqrt( sum( sum( (ErrorV) ) ) )*100; 


